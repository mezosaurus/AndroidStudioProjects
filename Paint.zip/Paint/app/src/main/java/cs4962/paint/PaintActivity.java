package cs4962.paint;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.opengl.Visibility;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import java.util.ArrayList;


public class PaintActivity extends Activity {

    private PaintView paintView;
    private PaintPaletteView paintPaletteView;
    private int[] colorPalette = new int[]{Color.BLACK, Color.BLUE, Color.CYAN, Color.GRAY, Color.GREEN, Color.LTGRAY, Color.MAGENTA, Color.RED, Color.YELLOW};
    private float preDragX = 0;
    private float preDragY = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout paintLayout = new LinearLayout(this);
        paintLayout.setOrientation(LinearLayout.VERTICAL);

        paintView = new PaintView(this);
        if (savedInstanceState != null) {
            Log.i("onCreate", "savedInstanceState is not null");
            ArrayList<PointF> points = savedInstanceState.getParcelableArrayList("points");
            ArrayList<Integer> colors = savedInstanceState.getIntegerArrayList("colors");
            paintView.setPoints(points);
            paintView.setColors(colors);
        }

        paintPaletteView = new PaintPaletteView(this);
        paintPaletteView.setPadding(10, 10, 10, 10);
        for (int splotchCount = 0; splotchCount < colorPalette.length; splotchCount++) {
            PaintSplotchView splotchView = new PaintSplotchView(this);
            splotchView.setPadding(10, 10, 10, 10);
            splotchView.setColor(colorPalette[splotchCount]);
            paintPaletteView.addView(splotchView);
        }
        paintPaletteView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                }
        });
        paintPaletteView.setOnSplotchTouchListener(new PaintPaletteView.OnSplotchTouchListener() {
            @Override
            public void onSplotchTouch(PaintSplotchView v, MotionEvent event) {
                // Get X and Y coords of touch event
                float touchX = event.getX();
                float touchY = event.getY();

                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        setActiveSplotch(v);
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (v.isActive()) {
                            v.setX(touchX - v.getRadius());
                            v.setY(touchY - v.getRadius());
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Check to see if splotch has been moved off palette, or if it has been moved on top of another splotch
                        if (checkSplotchOutOfPalette(v.getX(), v.getY())) {
                            v.setVisibility(View.GONE);
                            paintPaletteView.removeColor(v);
                            paintView.setPaintColor(Color.BLACK);
                        }
                        PaintSplotchView intersectSplotch = splotchesIntersect(v);
                        if (intersectSplotch != null) {
                            int colorMix = mixColor(intersectSplotch.getColor(), v.getColor());
                            addSplotch(colorMix);
                        }
                        v.setX(v.getLeft());
                        v.setY(v.getTop());
                        break;
                }
                v.invalidate();
            }
        });

        paintLayout.addView(paintView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER, 2));
        paintLayout.addView(paintPaletteView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER, 1));
        setContentView(paintLayout);
    }

    private void setActiveSplotch(View v) {
        // Loop through splotches to set active splotch to inactive
        for (int childIndex = 0; childIndex < paintPaletteView.getChildCount(); childIndex++) {
            View child = paintPaletteView.getChildAt(childIndex);
            if (!child.equals(v)) {
                ((PaintSplotchView)child).setActive(false);
            }
        }
        // Set current splotch to active
        ((PaintSplotchView)v).setActive(true);
        // Set paint color for drawing
        paintView.setPaintColor(((PaintSplotchView)v).getColor());
    }

    private PaintSplotchView splotchesIntersect (PaintSplotchView activeSplotch) {
        PaintSplotchView retVal = null;
        float splotchX = activeSplotch.getX();
        float splotchY = activeSplotch.getY();
        for (int childIndex = 0; childIndex < paintPaletteView.getChildCount(); childIndex++) {
            View child = paintPaletteView.getChildAt(childIndex);
            if (activeSplotch.equals((PaintSplotchView)child)) {
                continue;
            }

            float childY = child.getY();
            float childX = child.getX();
            float diameter = child.getMeasuredWidth();

            float distance = (float)Math.sqrt((childX - splotchX) * (childX - splotchX) +
                    (childY - splotchY) * (childY - splotchY));
            if(distance < diameter) {
                // splotch on splotch
                retVal = (PaintSplotchView)child;
                break;
            }
        }
        return retVal;
    }

    private void addSplotch (int color) {
        PaintSplotchView splotchView = new PaintSplotchView(this);
        splotchView.setPadding(10, 10, 10, 10);
        splotchView.setColor(color);
        paintPaletteView.addColor(splotchView);
    }

    private int mixColor (int colorOne, int colorTwo) {
        int redOne = Color.red(colorOne);
        int greenOne = Color.green(colorOne);
        int blueOne = Color.blue(colorOne);

        int redTwo = Color.red(colorTwo);
        int greenTwo = Color.green(colorTwo);
        int blueTwo = Color.blue(colorTwo);

        int mixRed = (redOne + redTwo) / 2;
        int mixGreen = (greenOne + greenTwo) / 2;
        int mixBlue = (blueOne + blueTwo) / 2;

        return Color.rgb(mixRed, mixGreen, mixBlue);
    }

    private boolean checkSplotchOutOfPalette (float x, float y) {
        boolean retVal = false;
        Rect layoutRect = paintPaletteView.getLayoutRect();
        float buffer = 80;
        float left = layoutRect.left - buffer;
        float top = layoutRect.top - buffer;
        float right = layoutRect.right + buffer;
        float bottom = layoutRect.bottom + buffer;

        if ((x > right || x < left) || (y > bottom || y < top)) {
            // splotch is beyond palette in either x or y direction
            retVal = true;
        }
        return retVal;
    }

    @Override
    public void onSaveInstanceState(Bundle state)
    {
        Log.i("onSaveInstanceState", "activity - saving state");
        super.onSaveInstanceState(state);
        state.putParcelableArrayList("points", paintView.getPoints());
        state.putIntegerArrayList("colors", paintView.getColors());
    }
}
