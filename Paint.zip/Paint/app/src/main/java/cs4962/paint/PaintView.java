package cs4962.paint;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

/**
 * Created by Ethan on 9/15/2014.
 */
public class PaintView extends View {
    // drawing path
    private Path path;
    // paints
    private Paint canvasPaint, drawPaint;
    // canvas
    private Canvas drawCanvas;
    // initial color
    private int initColor = 0xFFFFFFFF;
    // canvas bitmap
    private Bitmap canvasMap;
    // boolean used to determine between point or move
    private boolean drawPoint = true;
    // saved lists for redrawing
    private ArrayList<PointF> points = new ArrayList<PointF>();
    private ArrayList<Integer> colorList = new ArrayList<Integer>();

    public PaintView(Context context) {
        super(context);
        setSaveEnabled(true);
        // init class variables
        path = new Path();
        canvasPaint = new Paint(Paint.DITHER_FLAG);
        drawPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        drawPaint.setStrokeWidth(20);
        drawPaint.setStyle(Paint.Style.STROKE);
        drawPaint.setStrokeJoin(Paint.Join.ROUND);
        drawPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    public ArrayList<PointF> getPoints() {
        return points;
    }

    public void setPoints(ArrayList<PointF> pointList) {
        points = pointList;
    }

    public ArrayList<Integer> getColors() { return colorList; }

    public void setColors(ArrayList<Integer> colors) {
        colorList = colors;
    }

    public int getDrawPaintColor() {
        return drawPaint.getColor();
    }

    public void setPaintColor(int color) {
        drawPaint.setColor(color);
    }

    public Canvas getDrawCanvas() {
        return drawCanvas;
    }
    public void setCanvas(Canvas c) { drawCanvas = c; }

    public Bitmap getCanvasMap() {
        return canvasMap;
    }
    public void setBitmap(Bitmap map) { canvasMap = map; }


    @Override
    public void onWindowFocusChanged (boolean hasWindowFocus) {
        if (hasWindowFocus) {
            Log.i("onWindowFocusChanged", "calling redraw");
            reDrawPoints();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        //Log.i("onDraw", "drawing");
        super.onDraw(canvas);
        canvas.drawBitmap(canvasMap, 0, 0, canvasPaint);
        canvas.drawPath(path, drawPaint);
    }

    @Override
    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        Log.i("onSizeChanged", "size change event");
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        canvasMap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        drawCanvas = new Canvas(canvasMap);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float touchX = event.getX();
        float touchY = event.getY();
        points.add(new PointF(touchX, touchY));
        colorList.add(drawPaint.getColor());
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                path.moveTo(touchX, touchY);
                drawPoint = true;
                break;
            case MotionEvent.ACTION_MOVE:
                drawPoint = false;
                path.lineTo(touchX, touchY);
                break;
            case MotionEvent.ACTION_UP:
                if (drawPoint) {
                    drawCanvas.drawPoint(touchX, touchY, drawPaint);
                }
                else {
                    //path.lineTo(touchX, touchY);
                    drawCanvas.drawPath(path, drawPaint);
                    path.reset();
                }
                break;
        }
        invalidate();
        return true;
    }

    public void reDrawPoints() {
        for (int pointIndex = 0; pointIndex < points.size(); pointIndex++) {
            float x = points.get(pointIndex).x;
            float y = points.get(pointIndex).y;
            if (pointIndex == 0) {
                path.moveTo(x, y);
            }
            else {
                path.lineTo(x, y);
            }
            drawPaint.setColor(colorList.get(pointIndex));
            drawCanvas.drawPath(path, drawPaint);
            //path.reset();
            invalidate();
        }
        path.reset();
    }
}
